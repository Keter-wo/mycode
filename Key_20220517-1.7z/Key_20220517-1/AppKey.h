#ifndef _APPKEY_H_
#define _APPKEY_H_

//KEY_FUN DEFINITIONS
void Key_Fun_init(void);

#endif
